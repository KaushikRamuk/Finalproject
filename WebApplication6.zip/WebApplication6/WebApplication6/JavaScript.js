﻿
//#register{	
//    z-index: 21;
//    opacity: 0;
//}



//#toregister:target ~ #wrapper #register,
//#tologin:target ~ #wrapper #login{
//    z-index: 22;
//    animation-name: fadeInLeft;
//    animation-delay: .1s;
//}




//.animate{
//    animation-duration: 0.5s;
//    animation-timing-function: ease;
//        animation-fill-mode: both;
//    }
//@keyframes fadeInLeft {
//    0% {
//        opacity: 0;
//    transform: translateX(-20px);
//}
	
//    100% {
//        opacity: 1;
//    transform: translateX(0);
//}
//}

//#toregister:target ~ #wrapper #login,
//#tologin:target ~ #wrapper #register{
//    animation-name: fadeOutLeftBig;
//}

//@keyframes fadeOutLeft {
//    0% {
//        opacity: 1;
//    transform: translateX(0);
//}
	
//100% {
//    opacity: 0;
//transform: translateX(-20px);
//}
//}



