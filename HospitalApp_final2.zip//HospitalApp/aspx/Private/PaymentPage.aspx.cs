﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HospitalApp.BLL;
using HospitalApp.DAO;

namespace HospitalApp.aspx.Private
{
    public partial class PaymentPage : System.Web.UI.Page
    {
        AppointmentDAO appointmentDAO = new AppointmentDAO();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void SearchButton_Click(object sender, EventArgs e)
         {
            
            appointmentDAO.AppointmentID = int.Parse(SearchTextBox.Text.Trim());
            appointmentDAO = new AppointmentBLL().GetAppointmentByAppointmentID(appointmentDAO);
            AppointmentIDLabel.Text = appointmentDAO.AppointmentID.ToString();
            DoctorIDLabel.Text = appointmentDAO.DoctorID.ToString();
            AppointmentFeeLabel.Text = appointmentDAO.AppointmentFee.ToString();
            DoctorFeeLabel.Text = appointmentDAO.DoctorFee.ToString();
            AppointmentDateLabel.Text = appointmentDAO.AppointmentDate.ToString();

            Session["appointmentDAO"] = appointmentDAO;



        }

        protected void MakePaymentButton_Click(object sender, EventArgs e)
        {
            try
            {
                PaymentDAO paymentDAO = new PaymentDAO();
                UserDetailsDAO userDetailsDAO = new UserDetailsDAO();
                userDetailsDAO.LoginID = User.Identity.Name;
                appointmentDAO = Session["appointmentDAO"] as AppointmentDAO;
                paymentDAO.AppointmentID = appointmentDAO.AppointmentID;
                userDetailsDAO = new UserDetailsBLL().GetUserDetailsbyLoginID(userDetailsDAO);
                paymentDAO.PatientID = userDetailsDAO.PatientID;
                paymentDAO.Amount = appointmentDAO.DoctorFee + appointmentDAO.AppointmentFee;
                paymentDAO.AppointmentDate = appointmentDAO.AppointmentDate;
                paymentDAO.PaymentType = PaymentTpyeDownList.SelectedItem.ToString();

                if (new PaymentBLL().InsertPayment(paymentDAO))
                {
                    ErrorLabel.Text = "Payment Successfull";
                }
                else
                {

                }
            }
            catch(Exception ex)
            {
                ErrorLabel.Text = ex.Message;
            }


        }
    }
}