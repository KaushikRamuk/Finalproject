﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HospitalApp.DAO;
using HospitalApp.BLL;
using System.Data;
using System.Data.SqlClient;


namespace HospitalApp.aspx.Public
{
    public partial class Registration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void RegisterButton_Click(object sender, EventArgs e)
        {
            try
            {
                UserDetailsDAO userDetaislsDAO = new UserDetailsDAO();
                userDetaislsDAO.LoginID = UserIDTextBox.Text.Trim();
                if (!new UserDetailsBLL().CheckLoginID(userDetaislsDAO))
                {
                    userDetaislsDAO.LoginID = UserIDTextBox.Text.Trim();
                    userDetaislsDAO.Password = PasswordTextBox.Text.Trim();


                    userDetaislsDAO.FirstName = FirstNameTextBox.Text.Trim();
                    userDetaislsDAO.LastName = LastNameTextBox.Text.Trim();
                    userDetaislsDAO.FatherName = FatherNameTextbox.Text.Trim();
                    userDetaislsDAO.Sex = SexRadioButton.SelectedValue;
                    userDetaislsDAO.Address = AddressTextBox.Text.Trim();
                    userDetaislsDAO.LandlineNumber = LandlineNumberTextBox.Text.Trim();
                    userDetaislsDAO.MobileNumber = MobileNumberTextBox.Text.Trim();
                    userDetaislsDAO.DateOfBirth = DateTime.Parse(DateOfBirthTextBox.Text.Trim());


                    userDetaislsDAO.EmailID = EmailIDTextBox.Text.Trim();



                    if (new UserDetailsBLL().InsertUserDetails(userDetaislsDAO))
                    {
                        ErrorRegistrationLabel.Text = "Registered Successfully";
                        ErrorRegistrationLabel.BackColor = System.Drawing.Color.Blue;
                        Response.Redirect("~/HospitalAPP/aspx/Public/LoginPage.aspx");
                    }
                    else
                    {
                        ErrorRegistrationLabel.Text = "Error while inserting user information";
                        ErrorRegistrationLabel.BackColor = System.Drawing.Color.Red;
                    }
                }
                else
                {
                    ErrorRegistrationLabel.Text = "LoginID already exists";
                    ErrorRegistrationLabel.BackColor = System.Drawing.Color.Red;
                }

            }
            catch (Exception ex)
            {
                ErrorRegistrationLabel.Text = ex.Message;
                ErrorRegistrationLabel.BackColor = System.Drawing.Color.Red;
            }
        }

        protected void CancelButton_Click(object sender, EventArgs e)
        {
            UserIDTextBox.Text = "";
             PasswordTextBox.Text = "";
            FirstNameTextBox.Text = "";
            LastNameTextBox.Text = "";
            FatherNameTextbox.Text = "";
             AddressTextBox.Text = "";
            LandlineNumberTextBox.Text = "";
            MobileNumberTextBox.Text = "";
            DateOfBirthTextBox.Text = "";
            EmailIDTextBox.Text = "";

        }
    }

      
    }
 
