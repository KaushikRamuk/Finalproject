﻿create database dbComplaintManagementSystem
----------Tables------------------------------------------------------
create table tblSystemAdmin
(
SystemAdminId int primary key identity(1000,1),
Email varchar(50) not null unique,
Pssd varchar(20),
FirstName varchar(50),
LastName varchar(50),
)
select *from tblSystemAdmin

insert into tblSystemAdmin(Email,Pssd,FirstName,LastName) values('sysadmin@gmail.com','Qwer_1234','Amith','Nagaraj')
select *from tblSystemAdmin
----------------------------------------------------------------------

create table tblCustomers
(
CustomerId int primary key identity(10000,1),
FirstName varchar(50),
LastName varchar(50),
AccountNumber varchar(20) not null unique,
Branch varchar(50),
Addr varchar (200),
Email varchar(50) not null unique,
Pssd varchar(20) not null,
Phone varchar(20) not null,
SecurityQuestion varchar(200),
SecurityAnswer varchar(50)
)
select *from tblCustomers
--------------------------------------------------------------------

create table tblProductAdmin
(
ProductAdminId int primary key identity(2000,1),
Pssd varchar(20),
Email varchar(50) not null unique,
FirstName varchar(50),
LastName varchar(50),
)
select *from tblProductAdmin

insert into tblProductAdmin(Pssd,Email,FirstName,LastName) values('Qwer_1234','prod1@gmail.com','Peter','Varghese')
insert into tblProductAdmin(Pssd,Email,FirstName,LastName) values('Qwer_1234','prod2@gmail.com','Amith','Nagaraj')
insert into tblProductAdmin(Pssd,Email,FirstName,LastName) values('Qwer_1234','prod3@gmail.com','Chetan','Patil')
insert into tblProductAdmin(Pssd,Email,FirstName,LastName) values('Qwer_1234','prod4@gmail.com','Ajay','Kumar')
select *from tblProductAdmin

--------------------------------------------------------------------------------------------

create table tblProduct
(
ProductId int primary key identity(1,1),
ProductName varchar(20),
ProductAdminId int foreign key references tblProductAdmin(ProductAdminId)
)
select *from tblProduct

insert into tblProduct(ProductName,ProductAdminId) values('Credit Card',2000)
insert into tblProduct(ProductName,ProductAdminId) values('Debit Card',2001)
insert into tblProduct(ProductName,ProductAdminId) values('Online Banking',2002)
insert into tblProduct(ProductName,ProductAdminId) values('Loan',2003)
select *from tblProduct

---------------------------------------------------------------------------------------------

create table tblWorker
(
WorkerId int primary key identity(3000,1),
Pssd varchar(20) not null,
Email varchar(50) not null unique,
FirstName varchar(50),
LastName varchar(50),
ProductAdminId int foreign key references tblProductAdmin(ProductAdminId),
CurrentStatus varchar(10),
NoOfCases int
)
select *from tblWorker

insert into tblWorker(Pssd,Email,FirstName,LastName,ProductAdminId,CurrentStatus,NoOfCases) VALUES('Qwer_1234','worker1@gmail.com','Amith','Nagaraj',2000,'Free',0)
insert into tblWorker(Pssd,Email,FirstName,LastName,ProductAdminId,CurrentStatus,NoOfCases) VALUES('Qwer_1234','worker2@gmail.com','Chetan','Patil',2001,'Free',0)
insert into tblWorker(Pssd,Email,FirstName,LastName,ProductAdminId,CurrentStatus,NoOfCases) VALUES('Qwer_1234','worker3@gmail.com','Ajay','Kumar',2002,'Free',0)
insert into tblWorker(Pssd,Email,FirstName,LastName,ProductAdminId,CurrentStatus,NoOfCases) VALUES('Qwer_1234','worker4@gmail.com','Peter','Varghese',2003,'Free',0)
insert into tblWorker(Pssd,Email,FirstName,LastName,ProductAdminId,CurrentStatus,NoOfCases) VALUES('Qwer_1234','worker5@gmail.com','Prasad','T Hunashikatti',2000,'Free',0)
insert into tblWorker(Pssd,Email,FirstName,LastName,ProductAdminId,CurrentStatus,NoOfCases) VALUES('Qwer_1234','worker6@gmail.com','Adarsh','Sajeev',2001,'Free',0)
insert into tblWorker(Pssd,Email,FirstName,LastName,ProductAdminId,CurrentStatus,NoOfCases) VALUES('Qwer_1234','worker7@gmail.com','Ankit','Kumar Roy',2002,'Free',0)
insert into tblWorker(Pssd,Email,FirstName,LastName,ProductAdminId,CurrentStatus,NoOfCases) VALUES('Qwer_1234','worker8@gmail.com','Anup','Kumar Tiwary',2003,'Free',0)
insert into tblWorker(Pssd,Email,FirstName,LastName,ProductAdminId,CurrentStatus,NoOfCases) VALUES('Qwer_1234','worker9@gmail.com','Harishankar','Singh',2000,'Free',0)
insert into tblWorker(Pssd,Email,FirstName,LastName,ProductAdminId,CurrentStatus,NoOfCases) VALUES('Qwer_1234','worker10@gmail.com','Naji','Mohammed Ali',2001,'Free',0)
insert into tblWorker(Pssd,Email,FirstName,LastName,ProductAdminId,CurrentStatus,NoOfCases) VALUES('Qwer_1234','worker11@gmail.com','Nishant','Kumar',2002,'Free',0)
insert into tblWorker(Pssd,Email,FirstName,LastName,ProductAdminId,CurrentStatus,NoOfCases) VALUES('Qwer_1234','worker12@gmail.com','Danish','Ahmadullah',2003,'Free',0)
insert into tblWorker(Pssd,Email,FirstName,LastName,ProductAdminId,CurrentStatus,NoOfCases) VALUES('Qwer_1234','worker13@gmail.com','Subhajit','Paul',2000,'Free',0)
insert into tblWorker(Pssd,Email,FirstName,LastName,ProductAdminId,CurrentStatus,NoOfCases) VALUES('Qwer_1234','worker14@gmail.com','Nandakishor','A',2001,'Free',0)
insert into tblWorker(Pssd,Email,FirstName,LastName,ProductAdminId,CurrentStatus,NoOfCases) VALUES('Qwer_1234','worker15@gmail.com','Swapnil','Shashank',2002,'Free',0)
select *from tblWorker	

Select SUBSTRING(email, CHARINDEX('@', Email),10), *from tblWorker
where ProductAdminId=2002

select REPLACE(email,'g','hot'),* from tblworker
where ProductAdminId=2002
-------------------------------------------------------------------------------------------------

create table tblComplaint
(
ComplaintId int primary key identity(100,1), 
CustomerId int foreign key references tblCustomers(CustomerId),
WorkerId int foreign key references tblWorker(WorkerId),
ProductId int references tblProduct(ProductId),
ComplaintText varchar(8000),
WorkerQuery varchar(8000),
CustomerReply varchar(8000),
ComplaintStatus varchar(20),
ComplaintDate datetime,
Feedback varchar(8000),
)
select *from tblComplaint

-------------------------------------------------------------------------------------------------

select *from tblSystemAdmin
select *from tblProductAdmin
select *from tblWorker
select *from tblProduct
select *from tblCustomers
select *from tblComplaint

---------------------------------------------------------------------------------------------------

drop table tblSystemAdmin
drop table tblComplaint
drop table tblCustomers
drop table tblWorker
drop table tblProduct
drop table tblProductAdmin


---------------------------------------------------------------------------------------------------​
drop database dbComplaintManagementSystem