﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalApp.DAO;
using HospitalApp.DBLL;
namespace HospitalApp.BLL
{
   public class PatientBLL
    {

        public bool InsertPayment(PaymentDAO paymentDAO)
        {
            return new PaymentDBLL().InsertPayment(paymentDAO);
        }
    }
}
