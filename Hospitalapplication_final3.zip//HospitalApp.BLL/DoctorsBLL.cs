﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalApp.DAO;
using HospitalApp.DBLL;

namespace HospitalApp.BLL
{
   public class DoctorsBLL
    {
        public bool InsertDoctor(DoctorsDAO doctorsDAO)
        {
            return new DoctorDBLL().InsertDoctor(doctorsDAO);
        }
        public List<DoctorsDAO> GetDoctors()
        {
            return new DoctorDBLL().GetDoctors();
        }

        public DoctorsDAO GetDoctorByDoctorID(DoctorsDAO doctorsDAO)
        {
            return new DoctorDBLL().GetDoctorByDoctorID(doctorsDAO);
        }

    }
}
