﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalApp.DAO;
using HospitalApp.DBLL;

namespace HospitalApp.BLL
{
   public class AppointmentBLL
    {
        public bool InsertAppointment(AppointmentDAO appointmentDAO)
        {
            return new AppointmentDBLL().InsertAppointment(appointmentDAO);
        }

        public List<AppointmentDAO> GetAppointmentsByPatientID(AppointmentDAO appointmentDAO)
        {
            return new AppointmentDBLL().GetAppointmentsByPatientID(appointmentDAO);
        }

        public AppointmentDAO GetAppointmentByAppointmentID(AppointmentDAO appointmentDAO)
        {
            {
                return new AppointmentDBLL().GetAppointmentByAppointmentID(appointmentDAO);
            }
        }

        public List<AppointmentDAO> GetPatientsDetailsByDoctorLoginID(AppointmentDAO appointmentDAO)
        {
            return new AppointmentDBLL().GetPatientsDetailsByDoctorLoginID(appointmentDAO);
        }

    }
}
