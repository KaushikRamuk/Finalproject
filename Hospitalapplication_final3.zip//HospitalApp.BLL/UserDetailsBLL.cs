﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalApp.DAO;
using HospitalApp.DBLL;

namespace HospitalApp.BLL
{
   public class UserDetailsBLL
    {
        public bool InsertUserDetails(UserDetailsDAO userDetailsDAO)
        {
            return new UserDetailsDBLL().InsertUserDetails(userDetailsDAO);
        }

        public bool AuthenticateUser(UserDetailsDAO userDetailsDAO)
        {
            return new UserDetailsDBLL().AuthenticateUser(userDetailsDAO);
        }

        public bool CheckLoginID(UserDetailsDAO userDetailsDAO)
        {
            return new UserDetailsDBLL().CheckLoginID(userDetailsDAO);
        }
        public UserDetailsDAO GetUserDetailsbyLoginID(UserDetailsDAO userDetailsDAO)
        {
            return new UserDetailsDBLL().GetUserDetailsbyLoginID(userDetailsDAO);
        }
       
        public List<UserDetailsDAO> GetPatients()
        {
            return new UserDetailsDBLL().GetPatients();
        }
        public UserDetailsDAO GetKeyByLoginID(UserDetailsDAO userDetailsDAO)
        {
            return new UserDetailsDBLL().GetKeyByLoginID(userDetailsDAO);
       }


}

    }

