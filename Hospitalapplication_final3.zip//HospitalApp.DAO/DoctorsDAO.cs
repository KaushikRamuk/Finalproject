﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalApp.DAO
{
   public  class DoctorsDAO
    {
       public int DoctorID { get; set; }
       public String DoctorName { get; set; }
       public String DoctorSpecification{ get; set; }
        public Decimal DoctorFee { get; set; }
        public String LoginID { get; set; }

    }
}
