﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalApp.DAO
{
   public  class AppointmentDAO
    {
        public int AppointmentID { get; set; }
        public int PatientID { get; set; }
        public int DoctorID { get; set; }
        public String LoginID { get; set; }
        public String FirstName { get; set;}
        public String LastName { get; set; }
        public DateTime  AppointmentDate { get; set; }
        public double AppointmentFee { get; set; }
        public double DoctorFee { get; set; }

    }
}
