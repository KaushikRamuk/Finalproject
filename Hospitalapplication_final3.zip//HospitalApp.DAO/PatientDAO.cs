﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalApp.DAO
{
   public class PatientDAO
    {
        public int LoginID { get; set; }
        public int PatientID { get; set; }
        public String FirstName { get; set; }
        public String LastName { get; set; }
    }
}
