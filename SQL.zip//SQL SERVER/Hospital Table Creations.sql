
---Database creation-----
CREATE DATABASE NewHospital;
use NewHospital;

------ creating Registration table-------

CREATE TABLE Registration
       (
	      LoginID nvarchar(20) PRIMARY KEY NOT NULL,
		 Password nvarchar(20) not null,
	      FirstName nvarchar(40) not null,
		 LastName nvarchar(20) not null,
		 FatherName nvarchar(20) not null,
		 DateOfBirth Date not null,
		 [Address] nvarchar(max) not null,
		 Sex nvarchar(20) not null,
		 LandlineNumber nvarchar(20) not null,
		 MobileNumber nvarchar(20) not null,
		 EmailID nvarchar(20) not null,
		 [Key] nvarchar(25)  default 'Patient' NOT NULL
		 );

-------Creating Patients Table-------

CREATE TABLE Patients
       (
	    PatientID int  PRIMARY KEY  not null Identity(1,1),
      	 LoginID nvarchar(20) Foreign key  references     Registration(LoginID),            
		FirstName nvarchar(40) not null,
		LastName nvarchar(20) not null
		 )

-----Creating Doctors Table------

CREATE TABLE  Doctors
       (
	   DoctorID int  primary key not null Identity(100,1),
	   LoginID nvarchar(20),
	   DoctorName nvarchar(20) not null,
	   DoctorSpecification nvarchar(20) not null,
	   DoctorFee decimal 
	   );

------Creating Appoinments table----

 CREATE TABLE Appointments
       (
	      PatientID int  ,
		  DoctorID int ,
          AppointmentID int primary key not null  Identity(1000,1),
	      AppointmentDate Date,
		 AppointmentFee decimal 
	   )


-------Creating Payments table------

CREATE TABLE payments
     (
		PaymentID int Primary key identity(1,1),
		PatientID int   ,
		AppointmentID int    ,
		PaymentType nvarchar(20),
		Amount decimal
	);


------Inserting data

INSERT INTO Registration VALUES('sunil','sunil','mohan','kumar','mohan','1994-06-18','chennai','Male','9876543210','8985538672','sunil@gmail.com','Patient');
INSERT INTO Registration VALUES('Guru','Guru','Jinka','Guru','Krish','1994-06-18','Jmd','Male','9876543210','8985538672','Guru@gmail.com','operator');

INSERT INTO Registration VALUES('Pavan','Chowdam','Pavan','kumar','mohan','1994-06-18','Hyderabad','Male','9876543210','8985538672','Pavan@gmail.com','Doctor');

INSERT INTO Registration VALUES('Almas','Almas','Almas','Krish','mohan','1994-06-18','Bangalore','Female','9876543210','8985538672','Alamas@gmail.com','Doctor');

INSERT INTO Registration VALUES('Raghav','123456','Pavan','kumar','mohan','1994-06-18','Hyderabad','Male','9876543210','8985538672','Pavan@gmail.com','Doctor');

INSERT INTO Registration VALUES('Rams','123456','Pavan','kumar','mohan','1994-06-18','Pune','Male','9876543210','8985538672','Pavan@gmail.com','Doctor');

INSERT INTO Registration VALUES('Chandru','123456','Pavan','kumar','mohan','1994-06-18','Hyderabad','Male','9876543210','8985538672','Pavan@gmail.com','Admin');

INSERT INTO Registration VALUES('admin','123456','Pavan','kumar','mohan','1994-06-18','Hyderabad','Male','9876543210','8985538672','Pavan@gmail.com','Admin');

INSERT INTO Registration VALUES('operator','123456','Pavan','kumar','mohan','1994-06-18','Hyderabad','Male','9876543210','8985538672','Pavan@gmail.com','Operator');

INSERT INTO Registration VALUES('patient','123456','Pavan','kumar','mohan','1994-06-18','Hyderabad','Male','9876543210','8985538672','Pavan@gmail.com','Patient');

INSERT INTO Registration VALUES('doctor','123456','Pavan','kumar','mohan','1994-06-18','Pune','Male','9876543210','8985538672','Pavan@gmail.com','Doctor');
select * from Doctors

INSERT INTO Doctors(LoginID	,DoctorName,DoctorSpecification,DoctorFee ) VALUES ( 'doctor','Pavan','Heart',1000)

INSERT INTO Doctors(LoginID	,DoctorName,DoctorSpecification,DoctorFee ) VALUES ( 'Almas','Almas','Cardio',2000)

INSERT INTO Doctors(LoginID	,DoctorName,DoctorSpecification,DoctorFee ) VALUES ( 'Rams','Rams','ENT',3000)

INSERT INTO Doctors(LoginID	,DoctorName,DoctorSpecification,DoctorFee ) VALUES ( 'Raghav','Raghav','Dental',4000)


	    


		


