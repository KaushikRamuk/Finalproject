---------------------STORED PROCEDURES--------------------------


-----------Inserting UserDetails--------------------

  CREATE  PROCEDURE uspInsertUserDetails
        (
		@LoginID nvarchar(20),
		@Password nvarchar(20),
		@FirstName nvarchar(20),
		@LastName nvarchar(20),
        @FatherName nvarchar(20),
		@DateOfBirth nvarchar(20),
        @Address nvarchar(max),
		@Sex nvarchar(20),
		@LandlineNumber nvarchar(20),
		@MobileNumber nvarchar(20),
		@EmailID nvarchar(20),
		@Key nvarchar(20)='Patient'
		)
	AS
	BEGIN 
	  INSERT INTO Registration(LoginID,Password,FirstName,LastName,FatherName,DateOfBirth,Address,Sex,LandlineNumber,MobileNumber,EmailID) VALUES(@LoginID,@Password,@FirstName,@LastName,@FatherName,@DateOfBirth,@Address,@Sex,@LandlineNumber,@MobileNumber,@EmailID)
	  INSERT INTO  Patients(LoginID,FirstName,LastName) VALUES(@LoginID,@FirstName,@LastName)
	  END;



-------------------------UserAuthentication-----------------


	  CREATE PROCEDURE uspAuthenticateUser
       (
	   @LoginID nvarchar(20),
	   @Password nvarchar(20)
	   )
    AS
   BEGIN
            SELECT COUNT(*) FROM Registration
            WHERE LoginID=@LoginID AND Password=@Password
            END;


---------------------Checking LoginID--------------------


	  CREATE PROCEDURE uspCheckUserID
       (
	   @LoginID nvarchar(20)
	   
	   )
    AS
   BEGIN
             SELECT COUNT(*) FROM Registration
            WHERE LoginID=@LoginID 
             END;



	 -----------------Getting UserDetailsByLoginID------------


			 CREATE PROCEDURE uspGetUserDetailsbyLoginID
       (
	   @LoginID nvarchar(20)
	   
	   )
AS
BEGIN
   SELECT * FROM Registration
   join
   Patients
   on Registration.LoginID=Patients.LoginID
   WHERE Registration.LoginID=@LoginID 
   END;




   ----------------------Getting Patients---------------



   CREATE  PROCEDURE uspGetPatients
AS
BEGIN
SELECT Patients.PatientID,Registration.FirstName,Registration.LastName,Registration.FatherName,Registration.DateOfBirth,Registration.Sex,Registration.Address,Registration.LandLineNumber,Registration.MobileNumber,Registration.EmailID
FROM Registration
JOIN Patients
ON Registration.LoginID=Patients.LoginID
END;


-----------GettingKeyByLoginID--------------


CREATE PROCEDURE uspGetKeyByLoginID
     (
	      @LoginID nvarchar(20)
	   )
	   AS
	   Begin
	  SELECT [Key] FROM Registration 
	  WHERE LoginID=@LoginID

END;



---------------------Getting Doctors------------


	CREATE PROCEDURE uspGetDoctors
AS
BEGIN
SELECT * FROM Doctors
END;



---------------GettingDoctorsByDoctorID----------------

CREATE  PROCEDURE uspGetDoctorByID
(
@DoctorID nvarchar(20)
)
AS
BEGIN
SELECT * FROM Doctors where DoctorID=@DoctorID
END;


----------------Inserting Appointments--------------

CREATE  PROCEDURE   uspInsertAppoinments
(
 @PatientID int,
 @DoctorID int,
 @AppoinmentDate date,
 @AppointmentFee decimal=500

 )
AS
BEGIN
INSERT INTO  Appointments(PatientID,DoctorID,AppointmentDate,AppointmentFee) VALUES(@PatientID,@DoctorID,@AppoinmentDate,@AppointmentFee)
END;



--------------Gettting Appointments By AppointmentID-------



CREATE  PROCEDURE uspGetAppointmentByAppoinmentID
(
@AppointmentID int
)
AS
BEGIN 
   SELECT Appointments.AppointmentID,Appointments.PatientID,Appointments.AppointmentFee,Appointments.AppointmentDate,Doctors.DoctorFee,Doctors.DoctorID
   FROM Appointments 
   JOIN Doctors
   ON Appointments.DoctorID=Doctors.DoctorID
   WHERE Appointments.AppointmentID=@AppointmentID
   END;



--------------------Insert Payment-----------

 CREATE  PROCEDURE uspInsertPayment
   (
   @PatientID int,
   @AppointmentID int,
   @PaymentType nvarchar(20) ,
   @Amount decimal
   )
    AS
	BEGIN 
	    INSERT INTO Payments(PatientID,AppointmentID,PaymentType,Amount)  VALUES (@PatientID,@AppointmentID,@PaymentType,@Amount)
     END;

------------------Getting Doctors By DoctorID ---------
CREATE  PROCEDURE uspGetDoctorByDoctorID
(
@DoctorID nvarchar(20)
)
AS
BEGIN
SELECT * FROM Doctors where DoctorID=@DoctorID
END;

-------------------Getting Patients By DoctorLoginID---------------

 CREATE  PROCEDURE uspGetPatientsDetailsByDoctorLoginID
 (
    @LoginID nvarchar(20)
 )
 AS
 BEGIN
 SELECT Patients.PatientID,Patients.FirstName,Patients.LastName,Appointments.AppointmentID,Appointments.AppointmentDate
 FROM Doctors
 JOIN Appointments
 ON Appointments.DoctorID=Doctors.DoctorID
 join Patients
 on Appointments.PatientID=Patients.PatientID
 WHERE Doctors.LoginID=@LoginID
 END;




--------------Getting AppointmentsByLoginID-----------

CREATE  PROCEDURE upsGetAppointmentsByLoginID
(
@LoginID nvarchar(20)
)
AS
BEGIN
SELECT * FROM Appointments 
join
Patients 
on Appointments.PatientID=Patients.PatientID
where LoginID=@LoginID
END;



----------Getting AppointmentsByUserID--------------

CREATE  PROCEDURE uspGetAppoinmentsByUserID
(
@AppointmentID int
)
AS
BEGIN
SELECT * FROM Appointments where AppointmentID=@AppointmentID
END;


-----------------uspGetAppointmentsByPatientID----------------


CREATE  PROCEDURE uspGetAppointmentsByPatientID
(
@PatientID int
)
AS
BEGIN
SELECT * FROM Appointments where PatientID=@PatientID
END


------------uspGetAppointmentsByUserID----------------

CREATE  PROCEDURE uspGetAppointmentsByUserID
(
@AppointmentID int
)
AS
BEGIN
SELECT * FROM Appointments where AppointmentID=@AppointmentID
END;














	 






