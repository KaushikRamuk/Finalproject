﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalApp.DAO;
using System.Data;
using System.Data.SqlClient;

namespace HospitalApp.DBLL
{
   public class PaymentDBLL
    {
        //Inserting payment into database
        public bool InsertPayment(PaymentDAO paymentDAO)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=NewHospital;Integrated Security=true");
                connection.Open();
                if (connection.State == ConnectionState.Open)
                {
                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspInsertPayment";

                    command.Parameters.AddWithValue("@PatientID", paymentDAO.PatientID);
                    command.Parameters.AddWithValue("@Amount", paymentDAO.Amount);
                    command.Parameters.AddWithValue("@PaymentType", paymentDAO.PaymentType);
                    command.Parameters.AddWithValue("@AppointmentID", paymentDAO.AppointmentID);
                    //command.Parameters.AddWithValue("@AppointmentDate", paymentDAO.AppointmentDate);
                    command.Connection = connection;

                    int status = command.ExecuteNonQuery();
                    if (status >= 1)

                        return true;
                    else
                        return false;

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;

        }


    }
}
