﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalApp.DAO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;



namespace HospitalApp.DBLL
{
    public class DoctorDBLL
    {
        public bool InsertDoctor(DoctorsDAO doctorsDAO)
        {
          
            try
            {
                SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=NewHospital;Integrated Security=true");
                connection.Open();

                if (connection.State == ConnectionState.Open)
                {
                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspInsertDoctor";
              
                    //Need to remove doctorID bocz Indentity
                   // command.Parameters.AddWithValue("@DoctorID", "DOC101");
                    command.Parameters.AddWithValue("@DoctorName", doctorsDAO.DoctorName);
                    command.Parameters.AddWithValue("@DoctorSpecification", doctorsDAO.DoctorSpecification);
                    command.Parameters.AddWithValue("@DoctorFee", doctorsDAO.DoctorFee);
                    command.Connection = connection;


                    int status = command.ExecuteNonQuery();
                    if (status >= 1)

                        return true;
                    else
                        return false;

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }
        //Getting Doctors Details from Database
        public List<DoctorsDAO> GetDoctors()
        {
            List<DoctorsDAO> ListDoctorsDAO = new List<DoctorsDAO>();
            SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=NewHospital;Integrated Security=true");
            connection.Open();
            try
            {
                if (connection.State == ConnectionState.Open)
                {

                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspGetDoctors";
                    command.Connection = connection;
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {

                        DoctorsDAO DoctorDAO = new DoctorsDAO();

                        DoctorDAO.DoctorID = int.Parse(reader["DoctorID"].ToString());
                        DoctorDAO.DoctorName = reader["DoctorName"].ToString();
                        DoctorDAO.DoctorSpecification = reader["DoctorSpecification"].ToString();
                        DoctorDAO.DoctorFee = decimal.Parse(reader["DoctorFee"].ToString());
                        ListDoctorsDAO.Add(DoctorDAO);

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ListDoctorsDAO;

        }


        public DoctorsDAO GetDoctorByDoctorID(DoctorsDAO doctorsDAO)
        {
            SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=NewHospital;Integrated Security=true");
            connection.Open();
            try
            {
                if (connection.State == ConnectionState.Open)
                {

                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspGetDoctorByDoctorID";
                    command.Parameters.AddWithValue("@DoctorID", doctorsDAO.DoctorID);
                    command.Connection = connection;
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {

                        doctorsDAO.DoctorID = Convert.ToInt32(reader["DoctorID"].ToString());
                        doctorsDAO.DoctorName = reader["DoctorName"].ToString();
                        doctorsDAO.DoctorSpecification = reader["DoctorSpecification"].ToString();
                        doctorsDAO.DoctorFee = decimal.Parse( reader["DoctorFee"].ToString());
                    }

                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return doctorsDAO;

        }
    }
}
