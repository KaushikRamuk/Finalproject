﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalApp.DAO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace HospitalApp.DBLL
{
   public class PatientDBLL
    {

        public List<DoctorsDAO> GetDoctors()
        {
            List<DoctorsDAO> ListDoctorsDAO = new List<DoctorsDAO>();
            SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=HospitalManagement;Integrated Security=true");
            connection.Open();
            try
            {
                if (connection.State == ConnectionState.Open)
                {

                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspGetDoctors";
                    command.Connection = connection;
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {

                        DoctorsDAO DoctorDAO = new DoctorsDAO();
                        DoctorDAO.DoctorID = int.Parse(reader["DoctorID"].ToString());
                        DoctorDAO.DoctorName = reader["DoctorName"].ToString();
                        DoctorDAO.DoctorSpecification = reader["DoctorSpecification"].ToString();
                        ListDoctorsDAO.Add(DoctorDAO);

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ListDoctorsDAO;

        }

        public DoctorsDAO GetDoctorByID(DoctorsDAO doctorsDAO)
        {
            SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=HospitalManagement;Integrated Security=true");
            connection.Open();
            try
            {
                if (connection.State == ConnectionState.Open)
                {

                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspGetDoctorByID";
                    command.Parameters.AddWithValue("@DoctorID", doctorsDAO.DoctorID);
                    command.Connection = connection;
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {
                        doctorsDAO.DoctorID = int.Parse(reader["DoctorID"].ToString());
                        doctorsDAO.DoctorName = reader["DoctorName"].ToString();
                        doctorsDAO.DoctorSpecification = reader["DoctorSpecification"].ToString();
                        doctorsDAO.DoctorFee = decimal.Parse( reader["DoctorFee"].ToString());

                    }   

                    }
                }
            
            catch (Exception ex)
            {
                throw ex;
            }
            return doctorsDAO;

        }

        public bool InsertAppointment(AppointmentDAO appointmentDAO)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=HospitalManagement;Integrated Security=true");
               // SqlConnection connection= new SqlConnection();
               // connection.ConnectionString = ConfigurationManager.ConnectionStrings["NorthwindConnectionString"].ConnectionString;
         

                connection.Open();
                if (connection.State == ConnectionState.Open)
                {
                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspInsertAppoinments";
                    
                  //  command.Parameters.AddWithValue("@UserID", appointmentDAO.UserID);
                    command.Parameters.AddWithValue("@DoctorID", appointmentDAO.DoctorID);
                    command.Parameters.AddWithValue("@AppoinmentDate", appointmentDAO.AppointmentDate);    
                    command.Connection = connection;


                    int status = command.ExecuteNonQuery();
                    if (status >= 1)

                        return true;
                    else
                        return false;

                }   

            }
            catch (Exception ex)
            {
                //ErrorMessageLabel.Text = ex.Message;
            }
            return false;


        }

        public List<AppointmentDAO> GetAppointmentsByUserID(AppointmentDAO appointmentDAO)
        {

            List<AppointmentDAO> ListappointmentDAO = new List<AppointmentDAO>();
            SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=HospitalManagement;Integrated Security=true");
            connection.Open();
            try
            {
                if (connection.State == ConnectionState.Open)
                {

                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspGetAppoinmentsByUserID";
                    command.Parameters.AddWithValue("@PatientID", appointmentDAO.PatientID);
                    command.Connection = connection;
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {

                        // AppointmentDAO DoctorDAO = new DoctorsDAO();
                        appointmentDAO.DoctorID = int.Parse(reader["DoctorID"].ToString());
                        appointmentDAO.AppointmentDate = Convert.ToDateTime(reader["AppointmentDate"].ToString());
                        appointmentDAO.AppointmentFee = Convert.ToDouble(reader["AppointmentFee"].ToString());
                        ListappointmentDAO.Add(appointmentDAO);

                    }

                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return ListappointmentDAO;

        }

        public AppointmentDAO GetAppointmentByAppointmentID(AppointmentDAO appointmentDAO)
        {

           
            SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=HospitalManagement;Integrated Security=true");
            connection.Open();
            try
            {
                if (connection.State == ConnectionState.Open)
                {

                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspGetAppointmentByAppoinmentID";
                    command.Parameters.AddWithValue("@AppointmentID", appointmentDAO.AppointmentID);
                    command.Connection = connection;
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {

                        // AppointmentDAO DoctorDAO = new DoctorsDAO();
                        appointmentDAO.DoctorID = int.Parse(reader["DoctorID"].ToString());
                        appointmentDAO.DoctorFee = Convert.ToDouble(reader["DoctorFee"].ToString());
                        appointmentDAO.AppointmentDate = Convert.ToDateTime(reader["AppointmentDate"].ToString());
                        appointmentDAO.AppointmentFee = Convert.ToDouble(reader["AppointmentFee"].ToString());
                        

                    }

                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return appointmentDAO;

        }

        public List<AppointmentDAO> GetPatientsDetailsByDoctorID(AppointmentDAO appointmentDAO)
        {

            List<AppointmentDAO> ListappointmentDAO = new List<AppointmentDAO>();
            SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=HospitalManagement;Integrated Security=true");
            connection.Open();
            try
            {
                if (connection.State == ConnectionState.Open)
                {

                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspPatientDetailsByDoctorID";
                    command.Parameters.AddWithValue("@DoctorID", appointmentDAO.DoctorID);
                    command.Connection = connection;
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {

                        
                        appointmentDAO.PatientID = int.Parse(reader["PatientID"].ToString());
                        appointmentDAO.FirstName = reader["FirstName"].ToString();
                        appointmentDAO.LastName = reader["LastName"].ToString();
                        appointmentDAO.AppointmentID = Convert.ToInt32(reader["AppointmentID"].ToString());
                        appointmentDAO.AppointmentDate = Convert.ToDateTime(reader["AppointmentDate"].ToString());
                        ListappointmentDAO.Add(appointmentDAO);

                    }

                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return ListappointmentDAO;

        }


        public bool InsertPayment(PaymentDAO paymentDAO)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=HospitalManagement;Integrated Security=true");
                connection.Open();
                if (connection.State == ConnectionState.Open)
                {
                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspInsertPayment";

                    command.Parameters.AddWithValue("@PatientID", paymentDAO.PatientID);
                    command.Parameters.AddWithValue("@Amount", paymentDAO.Amount);
                    command.Parameters.AddWithValue("@PaymentType", paymentDAO.PaymentType);
                    command.Parameters.AddWithValue("@AppointmentID", paymentDAO.AppointmentID);
                    command.Parameters.AddWithValue("@AppointmentDate", paymentDAO.AppointmentDate);
                    command.Connection = connection;

                    int status = command.ExecuteNonQuery();
                    if (status >= 1)

                        return true;
                    else
                        return false;

                }

            }
            catch (Exception ex)
            {
                //ErrorMessageLabel.Text = ex.Message;
            }
            return false;

        }



    }
}
