﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HospitalApp.DAO;
using System.Data;
using System.Data.SqlClient;

namespace HospitalApp.DBLL
{
  public  class AppointmentDBLL
    {
        //making appointment
        public bool InsertAppointment(AppointmentDAO appointmentDAO)
        {
            try
            {
                SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=NewHospital;Integrated Security=true");
                connection.Open();
                if (connection.State == ConnectionState.Open)
                {
                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspInsertAppoinments";

                    command.Parameters.AddWithValue("@PatientID", appointmentDAO.PatientID);
                    command.Parameters.AddWithValue("@DoctorID", appointmentDAO.DoctorID);
                    command.Parameters.AddWithValue("@AppoinmentDate", appointmentDAO.AppointmentDate);
                    command.Connection = connection;


                    int status = command.ExecuteNonQuery();
                    if (status >= 1)

                        return true;
                    else
                        return false;

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;


        }


        //Getting AppoinmentsByPatientID

        public List<AppointmentDAO> GetAppointmentsByLoginID(AppointmentDAO appointmentDAO)
        {

            List<AppointmentDAO> ListappointmentDAO = new List<AppointmentDAO>();
            SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=NewHospital;Integrated Security=true");
            connection.Open();
            try
            {
                if (connection.State == ConnectionState.Open)
                {

                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspGetAppoinmentsByPatientID";
                    command.Parameters.AddWithValue("@PatientID", appointmentDAO.PatientID);
                    command.Connection = connection;
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {

                        // AppointmentDAO DoctorDAO = new DoctorsDAO();
                        appointmentDAO.DoctorID = Convert.ToInt32(reader["DoctorID"].ToString());
                        appointmentDAO.AppointmentDate = Convert.ToDateTime(reader["AppointmentDate"].ToString());
                        appointmentDAO.AppointmentFee = Convert.ToDouble(reader["AppointmentFee"].ToString());
                        ListappointmentDAO.Add(appointmentDAO);

                    }

                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return ListappointmentDAO;

        }


        //Getting AppoinmentsbyAppoinmentID
        public AppointmentDAO GetAppointmentByAppointmentID(AppointmentDAO appointmentDAO)
        {


            SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=NewHospital;Integrated Security=true");
            connection.Open();
            try
            {
                if (connection.State == ConnectionState.Open)
                {

                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspGetAppointmentByAppoinmentID";
                    command.Parameters.AddWithValue("@AppointmentID", appointmentDAO.AppointmentID);
                    command.Connection = connection;
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {

                        // AppointmentDAO DoctorDAO = new DoctorsDAO();
                        appointmentDAO.DoctorID = int.Parse(reader["DoctorID"].ToString());
                        appointmentDAO.PatientID = int.Parse(reader["PatientID"].ToString());
                        appointmentDAO.DoctorFee = double.Parse(reader["DoctorFee"].ToString());
                        appointmentDAO.AppointmentDate = Convert.ToDateTime(reader["AppointmentDate"].ToString());
                        appointmentDAO.AppointmentFee = double.Parse(reader["AppointmentFee"].ToString());


                    }

                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return appointmentDAO;

        }


        //Getting PatientsDetailsByDoctorID

        public List<AppointmentDAO> GetPatientsDetailsByDoctorLoginID(AppointmentDAO appointmentDAO)
        {

            List<AppointmentDAO> ListappointmentDAO = new List<AppointmentDAO>();
            SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=NewHospital;Integrated Security=true");
            connection.Open();
            try
            {
                if (connection.State == ConnectionState.Open)
                {

                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspGetPatientsDetailsByDoctorLoginID";
                    command.Parameters.AddWithValue("@LoginID", appointmentDAO.LoginID);
                    command.Connection = connection;
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {

                        appointmentDAO.PatientID = Convert.ToInt32(reader["PatientID"].ToString());
                        appointmentDAO.FirstName = reader["FirstName"].ToString();
                        appointmentDAO.LastName = reader["LastName"].ToString();
                        appointmentDAO.AppointmentID = Convert.ToInt32(reader["AppointmentID"].ToString());
                        appointmentDAO.AppointmentDate = Convert.ToDateTime(reader["AppointmentDate"].ToString());
                        ListappointmentDAO.Add(appointmentDAO);

                    }

                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return ListappointmentDAO;

        }

        public List<AppointmentDAO> GetAppointmentsByPatientID(AppointmentDAO appointmentDAO)
        {

            List<AppointmentDAO> ListappointmentDAO = new List<AppointmentDAO>();
            SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=NewHospital;Integrated Security=true");
            connection.Open();
            try
            {
                if (connection.State == ConnectionState.Open)
                {

                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspGetAppointmentsByPatientID";
                    command.Parameters.AddWithValue("@PatientID", appointmentDAO.PatientID);
                    command.Connection = connection;
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        AppointmentDAO newappointmentDAO = new AppointmentDAO();
                        newappointmentDAO.PatientID = Convert.ToInt32(reader["PatientID"].ToString());
                        newappointmentDAO.DoctorID = int.Parse(reader["DoctorID"].ToString());
                        newappointmentDAO.AppointmentFee = double.Parse( reader["AppointmentFee"].ToString());
                        newappointmentDAO.AppointmentID = Convert.ToInt32(reader["AppointmentID"].ToString());
                        newappointmentDAO.AppointmentDate = Convert.ToDateTime(reader["AppointmentDate"].ToString());
                        ListappointmentDAO.Add(newappointmentDAO);

                    }

                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return ListappointmentDAO;

        }
    }
}
