﻿using System;
using HospitalApp.DAO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;



namespace HospitalApp.DBLL
{
    public class UserDetailsDBLL
    {
        public bool InsertUserDetails(UserDetailsDAO userDetails)
        {

            try
            {
                SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=NewHospital;Integrated Security=true");
                connection.Open();

                if (connection.State == ConnectionState.Open)
                {
                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspInsertUserDetails";
                    command.Parameters.AddWithValue("@LoginID", userDetails.LoginID);
                    command.Parameters.AddWithValue("@Password", userDetails.Password);
                    command.Parameters.AddWithValue("@FirstName", userDetails.FatherName);
                    command.Parameters.AddWithValue("@LastName", userDetails.LastName);
                    command.Parameters.AddWithValue("@FatherName", userDetails.FatherName);
                    command.Parameters.AddWithValue("@DateOfBirth", userDetails.DateOfBirth);
                    command.Parameters.AddWithValue("@Address", userDetails.Address);
                    command.Parameters.AddWithValue("@Sex", userDetails.Sex);
                    command.Parameters.AddWithValue("@LandlineNumber", userDetails.LandlineNumber);
                    command.Parameters.AddWithValue("@MobileNumber", userDetails.MobileNumber);
                    command.Parameters.AddWithValue("@EmailID", userDetails.EmailID);
                    command.Connection = connection;


                    int status = command.ExecuteNonQuery();
                    if (status >= 1)

                        return true;
                    else
                        return false;

                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;

        }



        public bool AuthenticateUser(UserDetailsDAO userDetailsDAO)
        {

            try
            {
                SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=NewHospital;Integrated Security=true");
                connection.Open();


                if (connection.State == ConnectionState.Open)
                {
                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspAuthenticateUser";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LoginID", userDetailsDAO.LoginID);
                    command.Parameters.AddWithValue("@Password", userDetailsDAO.Password);
                    command.Connection = connection;

                    int status = int.Parse(command.ExecuteScalar().ToString());
                    if (status == 1)

                        return true;
                    else
                        return false;

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }
        public bool CheckLoginID(UserDetailsDAO userDetailsDAO)
        {

            try
            {
                SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=NewHospital;Integrated Security=true");
                connection.Open();


                if (connection.State == ConnectionState.Open)
                {
                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspCheckLoginID";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LoginID", userDetailsDAO.LoginID);

                    command.Connection = connection;

                    int status = int.Parse(command.ExecuteScalar().ToString());
                    if (status == 1)

                        return true;
                    else
                        return false;

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }
        public UserDetailsDAO GetUserDetailsbyLoginID(UserDetailsDAO userDetailsDAO)
        {

            try
            {
                SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=NewHospital;Integrated Security=true");
                connection.Open();


                if (connection.State == ConnectionState.Open)
                {
                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspGetUserDetailsbyLoginID";
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@LoginID", userDetailsDAO.LoginID);

                    command.Connection = connection;
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {

                        userDetailsDAO.PatientID = Convert.ToInt32(reader["PatientID"].ToString());
                        userDetailsDAO.FirstName = reader["FirstName"].ToString();

                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return userDetailsDAO;
        }



        // getting patients from database

        public List<UserDetailsDAO> GetPatients()
        {
            List<UserDetailsDAO> ListUserDetailsDAO = new List<UserDetailsDAO> ();
            SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=NewHospital;Integrated Security=true");
            connection.Open();
            try
            {
                if (connection.State == ConnectionState.Open)
                {

                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspGetPatients";
                    command.Connection = connection;
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        UserDetailsDAO userDetailsDAO = new UserDetailsDAO();
                        userDetailsDAO.PatientID = int.Parse(reader["PatientID"].ToString());
                        userDetailsDAO.FirstName = reader["FirstName"].ToString();
                        userDetailsDAO.LastName = reader["LastName"].ToString();
                        userDetailsDAO.FatherName = reader["FatherName"].ToString();
                        userDetailsDAO.DateOfBirth = Convert.ToDateTime(reader["DateOfBirth"].ToString());
                        userDetailsDAO.Sex = reader["Sex"].ToString();
                        userDetailsDAO.Address = reader["Address"].ToString();
                        userDetailsDAO.LandlineNumber = reader["LandlineNumber"].ToString();
                        userDetailsDAO.MobileNumber = reader["MobileNumber"].ToString();
                        userDetailsDAO.EmailID = reader["EmailID"].ToString();
                        ListUserDetailsDAO.Add(userDetailsDAO);

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ListUserDetailsDAO;

        }

        public UserDetailsDAO GetKeyByLoginID(UserDetailsDAO userDetailsDAO)
        {
            SqlConnection connection = new SqlConnection("Server=.\\SQLEXPRESS;Database=NewHospital;Integrated Security=true");
            connection.Open();
            try
            {
                if (connection.State == ConnectionState.Open)
                {

                    SqlCommand command = new SqlCommand();
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandText = "uspGetKeyByLoginID";
                    command.Parameters.AddWithValue("@LoginID", userDetailsDAO.LoginID);
                    command.Connection = connection;
                    SqlDataReader reader = command.ExecuteReader();
                    if (reader.Read())
                    {

                    userDetailsDAO.Key = reader["Key"].ToString();
                    }
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
            return userDetailsDAO;

        }

    }
}