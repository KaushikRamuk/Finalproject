﻿using System.Web.UI;

namespace HospitalApp.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}