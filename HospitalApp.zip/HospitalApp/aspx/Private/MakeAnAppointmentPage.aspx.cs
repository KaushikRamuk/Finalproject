﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HospitalApp.DAO;
using HospitalApp.BLL;

namespace HospitalApp.aspx.Private 
{
    public partial class MakeAnAppointmentPage : System.Web.UI.Page
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request.QueryString["DoctorID"] != null)
            {
                DoctorsDAO doctorsDAO = new DoctorsDAO();
                doctorsDAO.DoctorID = int.Parse(Request.QueryString["DoctorID"]);

                doctorsDAO = new DoctorsBLL().GetDoctorByDoctorID(doctorsDAO);

                DoctorIDLabel.Text = doctorsDAO.DoctorID.ToString();
                DoctorNameLabel.Text = doctorsDAO.DoctorName;
                SpecificationLabel.Text = doctorsDAO.DoctorSpecification;


            }
        }

        protected void ConfirmButton_Click(object sender, EventArgs e)
        {

            try
            {
                AppointmentDAO appointmentDAO = new AppointmentDAO();
                UserDetailsDAO userDetailsDAO = new UserDetailsDAO();
                DoctorsDAO doctorsDAO = new DoctorsDAO();
                // appointmentDAO.DoctorID = doctorsDAO.DoctorID;
                userDetailsDAO.LoginID = User.Identity.Name;

                userDetailsDAO = new UserDetailsBLL().GetUserDetailsbyLoginID(userDetailsDAO);
                appointmentDAO.PatientID = userDetailsDAO.PatientID;
              
                appointmentDAO.DoctorID = int.Parse(Request.QueryString["DoctorID"]);
                appointmentDAO.AppointmentDate = DateTime.Parse(datetimepickerTextBox.Text.Trim());
                if (new AppointmentBLL().InsertAppointment(appointmentDAO))
                {
                    ErrorLabel.Text = "Appointment fixed Successfully";
                    ErrorLabel.BackColor = System.Drawing.Color.Blue;
                }
                else
                {
                    ErrorLabel.Text = "Error appointment failed";
                    ErrorLabel.BackColor = System.Drawing.Color.Red;
                }
            }
            catch (Exception ex)
            {
                ErrorLabel.Text = ex.Message;
            }
        }
        }

 }
     
