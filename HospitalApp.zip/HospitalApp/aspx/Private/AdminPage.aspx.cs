﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HospitalApp.BLL;
using HospitalApp.DAO;

namespace HospitalApp.aspx.Private
{
    public partial class AdminPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                FillDoctors();
            }
        }
        private void FillDoctors()
        {
            

            DoctorsGridView.DataSource = new DoctorsBLL().GetDoctors() ;
            DoctorsGridView.DataBind();
        }

        protected void DoctorsGridView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        //protected void InsertButton_Click(object sender, EventArgs e)
        //{

        //    Button insertButton = sender as Button;

        //    GridViewRow gridViewRow =
        //        insertButton.Parent.Parent as GridViewRow;

        //    TextBox DoctorNameInsertTextBox =
        //        gridViewRow.FindControl("DoctorNameInsertTextBox") as TextBox;
        //    TextBox SpecificationInsertTextBox =
        //        gridViewRow.FindControl("SpecificationInsertTextBox") as TextBox;
        //    TextBox DoctorFeeTextBox =
        //        gridViewRow.FindControl("DoctorFeeInsertTextBox") as TextBox;
        //    DoctorsDAO doctorsDAO = new DoctorsDAO();
        //    doctorsDAO.DoctorName = DoctorNameInsertTextBox.Text.Trim();
        //    doctorsDAO.DoctorSpecification = SpecificationInsertTextBox.Text.Trim();
        //    doctorsDAO.DoctorFee = decimal.Parse(DoctorFeeTextBox.Text.Trim());

        //    if(new DoctorsBLL().InsertDoctor(doctorsDAO))
        //    {
        //        FillDoctors();
        //    }
        //    else
        //    {

        //    }



        //}
    }
}