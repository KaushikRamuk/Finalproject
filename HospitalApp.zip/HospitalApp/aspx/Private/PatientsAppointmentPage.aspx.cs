﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HospitalApp.BLL;
using HospitalApp.DAO;

namespace HospitalApp.aspx.Private
{
    public partial class PatientsAppointmentPage : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {


            try
            {
                AppointmentDAO appointmentDAO = new AppointmentDAO();

                UserDetailsDAO userDetailsDAO = new UserDetailsDAO();
                userDetailsDAO.LoginID = User.Identity.Name;

                userDetailsDAO = new UserDetailsBLL().GetUserDetailsbyLoginID(userDetailsDAO);

                appointmentDAO.PatientID = userDetailsDAO.PatientID;
                AppointmentsGridView.DataSource = new AppointmentBLL().GetAppointmentsByPatientID(appointmentDAO);
                AppointmentsGridView.DataBind();

            }
            catch (Exception ex)
            {
                ErrorLabel.Text = ex.Message;
            }



        }
    }
}