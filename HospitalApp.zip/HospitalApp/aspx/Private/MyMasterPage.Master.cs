﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HospitalApp.aspx.Master
{
    public partial class MyMasterPage : System.Web.UI.MasterPage
    {
        
        protected void Page_Load(object sender, EventArgs e)
        {
            PatientHyperLink.Visible = false;
            DoctorHyperLink.Visible = false;
            AdminHyperLink.Visible = false;
            OperatorHyperLink.Visible = false;
            if (Session["Key"] == null)
            {

            }
            else if (Session["Key"].ToString()=="Patient")
            {
                PatientHyperLink.Visible = true;
            }
            else if (Session["Key"].ToString() == "Doctor")
            {
                DoctorHyperLink.Visible = true;
            }
            else if (Session["Key"].ToString() == "Admin")
            {
               AdminHyperLink.Visible = true;
            }
            else if (Session["Key"].ToString() == "Operator")
            {
                OperatorHyperLink.Visible = true;
            }
            
        }
    }
}