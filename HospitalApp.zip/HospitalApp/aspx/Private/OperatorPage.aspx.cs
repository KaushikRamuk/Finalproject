﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HospitalApp.DAO;
using HospitalApp.BLL;

namespace HospitalApp.aspx.Private
{
    public partial class OperatorPage : System.Web.UI.Page
    {


        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                OperatorGridView.DataSource = new UserDetailsBLL().GetPatients();
                OperatorGridView.DataBind();
            }
            catch(Exception ex)
            {
                ErrorLabel.Text = ex.Message;
            }
        }


    }
}