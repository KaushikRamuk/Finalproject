﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HospitalApp.BLL;
using HospitalApp.DAO;
namespace HospitalApp.aspx.Private
{
    public partial class PatientPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
            
            

            try
            {
                DoctorsGridView.DataSource = new DoctorsBLL().GetDoctors();
                DoctorsGridView.DataBind();

            }
            catch (Exception ex)
            {
                ErrorLabel.Text = ex.Message;
            }
        }

        protected void DoctorsGridView_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}