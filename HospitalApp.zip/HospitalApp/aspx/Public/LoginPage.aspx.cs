﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;
using HospitalApp.DAO;
using HospitalApp.BLL;

namespace HospitalApp.aspx.Public
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
           // ErrorLabel.Text = FormsAuthentication.GetRedirectUrl(UserNameTextBox.Text.Trim(), false);

        }

        protected void loginButton_Click(object sender, EventArgs e)
        {

            try
            {
                UserDetailsDAO userDetailsDAO = new UserDetailsDAO();
                userDetailsDAO.LoginID = UserNameTextBox.Text.Trim();
                userDetailsDAO.Password = PasswordTextBox.Text.Trim();
                //code to check the LogID in data Base

   
                if (new UserDetailsBLL().AuthenticateUser(userDetailsDAO))
                {
                    Session["LoginID"] = UserNameTextBox.Text.Trim();
                    Session["Key"] = new UserDetailsBLL().GetKeyByLoginID(userDetailsDAO).Key;
                    if (new UserDetailsBLL().GetKeyByLoginID(userDetailsDAO).Key == "Doctor")
                    {
                       

                        FormsAuthentication.SetAuthCookie(UserNameTextBox.Text.Trim(),false);
                        Response.Redirect("~/aspx/Private/DoctorMypage.aspx");
                   
                    }

                    else if (new UserDetailsBLL().GetKeyByLoginID(userDetailsDAO).Key == "Operator")
                        {
                       
                        FormsAuthentication.SetAuthCookie(UserNameTextBox.Text.Trim(), false);
                        Response.Redirect("~/aspx/Private/OperatorPage.aspx");
                   
                       }
                    else if (new UserDetailsBLL().GetKeyByLoginID(userDetailsDAO).Key == "Admin")
                    {
                   
                        FormsAuthentication.SetAuthCookie(UserNameTextBox.Text.Trim(), false);
                        Response.Redirect("~/aspx/Private/AdminPage.aspx");
                        
                    }
                    else if (new UserDetailsBLL().GetKeyByLoginID(userDetailsDAO).Key == "Patient")
                    {

                        FormsAuthentication.SetAuthCookie(UserNameTextBox.Text.Trim(), false);
                        Response.Redirect("~/aspx/Private/PatientPage.aspx");

                    }


                    FormsAuthentication.RedirectFromLoginPage(UserNameTextBox.Text.Trim(), false);
                   

                }
                else
                {
                    ErrorLabel.Text = "User not present";
                    ErrorLabel.BackColor = System.Drawing.Color.Red;
                }
            }
            catch (Exception ex)
            {
                ErrorLabel.Text = ex.Message;
            }
        }
    }
}